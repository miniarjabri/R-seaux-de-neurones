/**
 * 
 */
/**
 * @author rimel
 *
 */
module reseau_neurone {
}